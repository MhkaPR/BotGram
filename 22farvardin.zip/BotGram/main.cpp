#include "botgram.h"
#include "capchabuilder.h"
#include <QApplication>
#include"check.h"


int main(int argc, char *argv[])
{
    check c;
    QApplication a(argc, argv);
    botgram w;



    w.show();
    return a.exec();
}
