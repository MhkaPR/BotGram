#ifndef RECVANDCONNECTIONHANDLER_H
#define RECVANDCONNECTIONHANDLER_H
void RecvHandler(char *buffer, int dataLen)
{

}
void Connection(bool flag)
{

}

#endif // RECVANDCONNECTIONHANDLER_H
