#ifndef CHECK_H
#define CHECK_H
#include<iostream>

using namespace std;
class check
{
public:
    check();
    static string jj;

};

#endif // CHECK_H
