#include "capchacreator.h"

capchaCreator::capchaCreator(QObject *parent) : QObject(parent)
{

}
