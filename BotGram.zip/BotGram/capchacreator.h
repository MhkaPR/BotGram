#ifndef CAPCHACREATOR_H
#define CAPCHACREATOR_H

#include <QObject>

class capchaCreator : public QObject
{
    Q_OBJECT
public:
    explicit capchaCreator(QObject *parent = nullptr);

signals:

public slots:
};

#endif // CAPCHACREATOR_H
