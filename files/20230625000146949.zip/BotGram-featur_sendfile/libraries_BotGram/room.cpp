#include "room.h"

Room::Room()
{

}

Room *Room::selectRoom(short RoomID)
{


}

