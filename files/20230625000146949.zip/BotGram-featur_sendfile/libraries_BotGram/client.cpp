#include "client.h"

client::client()
{

}
