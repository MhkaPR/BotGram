#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QProcess>
#include <QThread>
#include <QFile>
#include <windows.h>
#include <QRandomGenerator>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

void MainWindow::start()
{

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    srand(time(0));
    int randomNumber = rand()%9000 + 1000;// generate a random number between 1000 and 9999
    QString randomString = QString::number(randomNumber);
    QString f =randomString + ".png";
    f= "Qrs/" +f;
    QFile g;
    g.setFileName(f);
    QString program = "curl";
    QStringList arguments;

    // toolid adad random beyn 1000 and 9999

    // Modify the API call to include the random number
    QString data = "Code/" + randomString;
    QString tempData = "http://api.qrserver.com/v1/create-qr-code/?data=" + data + "&size=200x200\"";
    arguments <<tempData << "-o" << f;

    QProcess *myProcess = new QProcess(this);
    myProcess->start(program, arguments);

    if(!g.exists())
        ui->label->setText("wait for loading...");

    while (!g.exists());

    QPixmap p;
    p.load("./" + f );
    ui->label->setPixmap(p);

    // estekhraj addad random az scanned data va namayesh an
//    QString scannedData = "cachalbash1234"; // assume this is the scanned data(farz bar inkeh in adad mord nazar), w
//    QString extractedString = scannedData.mid(9);   //estekhraj adad random tavasot pak kardan 9 caracter ("cachalbash")

//    int extractedNumber = extractedString.toInt(); // tabdil string estekhraj shode be integer

//    if (extractedNumber >= 1000 && extractedNumber <= 9999) {
//        ui->label->setText("Random number: " + QString::number(extractedNumber)); // namayesh adad random
//    } else {
//        ui->label->setText("Invalid scanned data.");
//    }
}
