#include "page1.h"
#include "ui_page1.h"
#include "page2.h"
#include<cstdlib>
page1::page1(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::page1)
{
    ui->setupUi(this);
page2 s;

}

page1::~page1()
{
    delete ui;
}

