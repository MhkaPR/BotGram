#include "page2.h"
#include "ui_page2.h"

page2::page2(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::page2)
{
    ui->setupUi(this);
}

page2::~page2()
{
    delete ui;
}
void page2::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    Captcha cp;
    cp.randomize();
    cp.setDifficulty(0);
   /* cp.loadDictionary("dictionary.txt");
    cp.setTextGeneration(Captcha::TextGeneration_Dictionary);*/
    cp.generateText();
    painter.drawImage(100, 100, cp.captchaImage());
}
