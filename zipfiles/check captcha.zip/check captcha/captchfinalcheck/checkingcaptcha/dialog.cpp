#include "dialog.h"
#include "ui_dialog.h"
#include <QPainterPath>
#include <QPainter>
#include <QtMath>

Dialog::Dialog(QWidget *parent) :
   // QWidget(parent),
    QWidget(parent),
    ui(new Ui::Dialog)
   // ui(new Ui::Dialog)
{
    ui->setupUi(this);
}

Dialog::~Dialog()
{
    delete ui;
}


void Dialog::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
	Captcha cp;
	cp.randomize();
    cp.setDifficulty(0);
   /* cp.loadDictionary("dictionary.txt");
    cp.setTextGeneration(Captcha::TextGeneration_Dictionary);*/
	cp.generateText();
    painter.drawImage(100, 100, cp.captchaImage());
}
