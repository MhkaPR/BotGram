#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDir>
#include <QThread>
#include <QProcess>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{

ui->setupUi(this);


QString program = "curl";
   QStringList arguments;
   QString f = "2256984.png";
   arguments <<"http://api.qrserver.com/v1/create-qr-code/?data=2256984&size=200x200\"" << "-o" << f;

   QProcess *myProcess = new QProcess(parent);
   myProcess->start(program, arguments);
   //system("curl \"http://api.qrserver.com/v1/create-qr-code/?data=cachalbash&size=100x100\" -o test.png");
//QThread::sleep(1000);
    QPixmap p;
    p.load("./" + f );
    ui->label->setPixmap(p);

}

MainWindow::~MainWindow()
{
    delete ui;
}

