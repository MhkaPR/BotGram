#include "mainwindow.h"
#include <QApplication>
#include <cpp/qrcodegen.hpp>
#include "cpp/qrcodegen.hpp"
#include <Qrcode.h>
#include <string>
#include <vector>

    using namespace qrcodegen;
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;



    w.show();
    return a.exec();
}
